import { useEffect, useRef, useState } from "react";

/* d3 */
import {
  arc as d3Arc,
  format as d3Format,
  hierarchy,
  interpolate,
  partition,
  select as d3Select,
  scaleOrdinal,
  schemeTableau10,
} from "d3";

/* components */
import { useData } from "./useData";
import { Loading } from "../Loading";

/* css */
import "./SunburstChart.css";

const RADIUS_DIVIDER = 11.5;
const VIEWBOX_MIN_X = (w) => -1 * (w / 2.5);
const VIEWBOX_MIN_Y = (h) => -1 * (h / 2.4);
const DEFAULT_MAIN_TITLE = "Physical Sciences";
const TEXT_WRAP_COUNT = (18 / RADIUS_DIVIDER) * 10;

export const SunburstChart = ({
  width = window.innerWidth,
  height = window.innerHeight,
  onSelectedTopic,
  selectedDomain,
}) => {
  const radius = width / RADIUS_DIVIDER;

  const [loading, setLoading] = useState(true);
  const svgRef = useRef();
  const data = useData(selectedDomain);

  let parent = null;
  let root = null;
  let path = null;
  let arc = null;
  let label = null;

  /* Generators */
  const arcGenerator = () => {
    return d3Arc()
      .startAngle((d) => d.x0)
      .endAngle((d) => d.x1)
      .padAngle((d) => Math.min((d.x1 - d.x0) / 2, 0.005))
      .padRadius(radius * 1.5)
      .innerRadius((d) => d.y0 * radius)
      .outerRadius((d) => Math.max(d.y0 * radius, d.y1 * radius - 1));
  };
  const pathGenerator = (svgElement, rootData, arcGenerator, color) => {
    return d3Select(svgElement)
      .append("g")
      .selectAll("path")
      .data(rootData.descendants().slice(1))
      .join("path")
      .attr("fill", (d) => {
        while (d.depth > 1) d = d.parent;
        return color(d.data.name);
      })
      .attr("fill-opacity", (d) =>
        arcVisible(d.current) ? (d.children ? 0.6 : 0.4) : 0
      )
      .attr("pointer-events", (d) => (arcVisible(d.current) ? "auto" : "none"))
      .attr("d", (d) => arcGenerator(d.current))
      .on("mouseover", function (event, d) {
        d3Select(this).attr("fill-opacity", 1);
        // .attr("fill", "gold"); // Optionally change the color to something brighter
      })
      .on("mouseout", function (event, d) {
        d3Select(this)
          .attr("fill-opacity", (d) =>
            arcVisible(d.current) ? (d.children ? 0.6 : 0.4) : 0
          )
          .attr("fill", (d) => {
            while (d.depth > 1) d = d.parent;
            return color(d.data.name);
          });
      });
  };

  // const pathGenerator = (svgElement, rootData, arcGenerator, color) => {
  //   return d3Select(svgElement)
  //     .append("g")
  //     .selectAll("path")
  //     .data(rootData.descendants().slice(1))
  //     .join("path")
  //     .attr("fill", (d) => {
  //       while (d.depth > 1) d = d.parent;
  //       return color(d.data.name);
  //     })
  //     .attr("fill-opacity", (d) =>
  //       arcVisible(d.current) ? (d.children ? 0.6 : 0.4) : 0
  //     )
  //     .attr("pointer-events", (d) => (arcVisible(d.current) ? "auto" : "none"))
  //     .attr("d", (d) => arcGenerator(d.current));
  // };

  const labelEllipsis = (text) => {
    return text.length > TEXT_WRAP_COUNT ? text.substring(0, 16) + "..." : text;
  };

  // const labelGenerator = (svgElement, rootData, maxHeight = 23) => {
  //   return d3Select(svgElement)
  //     .append("g")
  //     .attr("pointer-events", "none")
  //     .attr("text-anchor", "middle")
  //     .style("user-select", "none")
  //     .selectAll("text")
  //     .data(rootData.descendants().slice(1))
  //     .join("text")
  //     .attr("dy", "0.35em")
  //     .attr("fill-opacity", (d) => +labelVisible(d.current))
  //     .attr("transform", (d) => labelTransform(d.current))
  //     .text((d) => labelEllipsis(d.data.name));
  // };

  const labelGenerator = (svgElement, rootData) => {
    return d3Select(svgElement)
      .append("g")
      .attr("pointer-events", "none")
      .attr("text-anchor", "middle")
      .style("user-select", "none")
      .selectAll("text")
      .data(rootData.descendants().slice(1))
      .join("text")
      .attr("dy", "0.35em")
      .attr("fill-opacity", (d) => +labelVisible(d.current))
      .attr("transform", (d) => labelTransform(d.current))
      .each(function (d) {
        const textEl = d3Select(this);
        const arcHeight = (d.current.y1 - d.current.y0) * radius;
        const maxLines = Math.floor(arcHeight / 12); // 12px per line
        const words = d.data.name.split(/\s+/);

        // Clear existing text
        textEl.text(null);

        // Add lines until we run out of space
        let line = [];
        let lineCount = 0;
        let tspan = textEl.append("tspan").attr("x", 0).attr("dy", "0em");

        words.forEach((word) => {
          const testLine = [...line, word].join(" ");
          tspan.text(testLine);

          // If line is too wide or we've hit max lines
          if (
            tspan.node().getComputedTextLength() > arcHeight * 0.8 ||
            lineCount >= maxLines - 1
          ) {
            tspan.text(line.join(" "));
            line = [word];
            lineCount++;
            tspan = textEl.append("tspan").attr("x", 0).attr("dy", "1em");
          } else {
            line.push(word);
          }
        });

        // Add ellipsis if truncated
        if (lineCount >= maxLines - 1 && words.length > line.length) {
          tspan.text(line.join(" ") + "...");
        } else {
          tspan.text(line.join(" "));
        }
      });
  };

  const circleGenerator = (svgElement, rootData, radius) => {
    return d3Select(svgElement)
      .append("circle")
      .datum(rootData)
      .attr("r", radius)
      .attr("fill", "none")
      .attr("pointer-events", "all")
      .on("click", clicked);
  };

  const mainTitleGenerator = (svgElement) => {
    return d3Select(svgElement)
      .append("g")
      .attr("class", "main-title-wrapper")
      .append("text")
      .attr("class", "main-title")
      .style("font-weight", "bold")
      .text(selectedDomain);
  };

  /* Hooks */
  useEffect(() => {
    if (svgRef.current && data) {
      setLoading(false);
      // const color = scaleOrdinal(
      //   quantize(interpolateRainbow, data.children.length + 1)
      // );
      const color = scaleOrdinal(schemeTableau10);
      const chartHierarchy = hierarchy(data)
        .sum((d) => d.value)
        .sort((a, b) => b.value - a.value);

      root = partition().size([2 * Math.PI, chartHierarchy.height + 1])(
        chartHierarchy
      );

      root.each((d) => (d.current = d));

      mainTitleGenerator(svgRef.current);

      // Create the arc generator.
      arc = arcGenerator();

      // Append the arcs.
      path = pathGenerator(svgRef.current, root, arc, color);
      // Make them clickable if they have children.
      path
        .filter((d) => d.children)
        .style("cursor", "pointer")
        .on("click", clicked);

      path
        .filter((d) => d.children === undefined)
        .style("cursor", "pointer")
        .on("click", topicClicked);

      const format = d3Format(",d");
      path.append("title").text(
        (d) => {
          //   {
          //   d.ancestors().length
          // }
          let titleStr = "";
          let length = d.ancestors().length;

          if (length > 1) {
            titleStr += `${"Field: " + d.ancestors()[length - 2].data.name}`;
          }
          if (length > 2) {
            titleStr += `${
              "\nSub Field: " + d.ancestors()[length - 3].data.name
            }`;
          }
          if (length > 3) {
            titleStr += `${"\nTopic: " + d.ancestors()[length - 4].data.name}`;
          }
          // if (length > 4) {
          //   titleStr += `${"\nTopic: " + d.ancestors()[length - 5].data.name}`;
          // }
          titleStr += `${"\n\nWorks: " + format(d.value).toString()}`;

          return titleStr;
        }

        // `${d
        //   .ancestors()
        //   .map((d) => d.data.name)
        //   .reverse()
        //   .join("/")}\nWorks: ${format(d.value)}`
      );
      label = labelGenerator(svgRef.current, root);

      parent = circleGenerator(svgRef.current, root, radius);
    }
  }, [data, selectedDomain]);

  /* Events */
  function topicClicked(event, p) {
    onSelectedTopic(p);
  }

  function clicked(event, p) {
    // set main title of sunburst for clicked element name
    d3Select(".main-title").text(p?.data?.name || selectedDomain);

    parent.datum(p.parent || root);

    root.each(
      (d) =>
        (d.target = {
          x0:
            Math.max(0, Math.min(1, (d.x0 - p.x0) / (p.x1 - p.x0))) *
            2 *
            Math.PI,
          x1:
            Math.max(0, Math.min(1, (d.x1 - p.x0) / (p.x1 - p.x0))) *
            2 *
            Math.PI,
          y0: Math.max(0, d.y0 - p.depth),
          y1: Math.max(0, d.y1 - p.depth),
        })
    );

    const t = d3Select(svgRef.current)
      .transition()
      .duration(event.altKey ? 7500 : 750);

    // Transition the data on all arcs, even the ones that aren’t visible,
    // so that if this transition is interrupted, entering arcs will start
    // the next transition from the desired position.
    path
      .transition(t)
      .tween("data", (d) => {
        const i = interpolate(d.current, d.target);
        return (t) => (d.current = i(t));
      })
      .filter(function (d) {
        return +this.getAttribute("fill-opacity") || arcVisible(d.target);
      })
      .attr("fill-opacity", (d) =>
        arcVisible(d.target) ? (d.children ? 0.6 : 0.4) : 0
      )
      .attr("pointer-events", (d) => (arcVisible(d.target) ? "auto" : "none"))

      .attrTween("d", (d) => () => arc(d.current));

    label
      .filter(function (d) {
        return +this.getAttribute("fill-opacity") || labelVisible(d.target);
      })
      .transition(t)
      .attr("fill-opacity", (d) => +labelVisible(d.target))
      .attrTween("transform", (d) => () => labelTransform(d.current));
  }

  function arcVisible(d) {
    return d.y1 <= 3 && d.y0 >= 1 && d.x1 > d.x0;
  }

  function labelVisible(d) {
    return d.y1 <= 3 && d.y0 >= 1 && (d.y1 - d.y0) * (d.x1 - d.x0) > 0.03;
  }

  function labelTransform(d) {
    const x = (((d.x0 + d.x1) / 2) * 180) / Math.PI;
    const y = ((d.y0 + d.y1) / 2) * radius;
    return `rotate(${x - 90}) translate(${y},0) rotate(${x < 180 ? 0 : 180})`;
  }

  return (
    <div
      className="sunburst-chart"
      style={{
        width,
        height,
      }}
    >
      {loading && <Loading />}
      <svg
        viewBox={`${VIEWBOX_MIN_X(width)}, ${VIEWBOX_MIN_Y(
          height
        )}, ${width}, ${height}`}
        ref={svgRef}
      ></svg>
    </div>
  );
};
