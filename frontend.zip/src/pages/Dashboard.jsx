import React from "react";

function Dashboard() {
  return <div>Data Visualization Project</div>;
}

export default Dashboard;
